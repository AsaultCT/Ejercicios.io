using System;
class MainClass {
  public static void Main (string[] args) {
    Console.WriteLine ("Ingrese sus ingresos mensuales:");
    float ingresos = float.Parse(Console.ReadLine());
    float alimentacion = ingresos * 0.30;
    float vivienda = ingresos * 0.20;
    float transporte = ingresos * 0.10;
    float recreacion = ingresos * 0.10;
    float dinero_restante = ingresos - (alimentacion + vivienda + transporte + recreacion);
    Console.WriteLine($"Los gastos de alimentación son: {alimentacion} (30% en total)");
    Console.WriteLine($"Los gastos de vivienda son: {vivienda} (20% en total)");
    Console.WriteLine($"Los gastos de transporte son: {transporte} (10% en total)");
    Console.WriteLine($"Los gastos de recreación son: {recreacion} (10% en total)");;
    Console.WriteLine($"El dinero restante es: {dinero_restante} ");
  }
}
