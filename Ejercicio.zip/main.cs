using System;

class Program {
  public static void Main (string[] args) {
    float peso_colombiano = 3800;
    Console.WriteLine ("Ingrese la cantidad de dolares a convetir:");
    float cantidad_dolares = float.Parse(Console.ReadLine());
    float conversion = cantidad_dolares * peso_colombiano;
    Console.WriteLine($"{cantidad_dolares} dolares equivalen a {conversion} pesos colombianos");
  }
}