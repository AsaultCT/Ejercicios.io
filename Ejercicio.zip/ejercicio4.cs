using System;
class MainClass {
  public static void Main (string[] args) {
    Console.WriteLine ("Ingres el valor del articulo comprado:");
    float valor_articulo = float.Parse(Console.ReadLine());
    float valor_extra = valor_articulo * 0.30;
    Console.WriteLine($"El valor extra que debe ser agregado para tener una ganancia del 30% es de: {valor_extra}");
  }
}
