using System;
class MainClass {
  public static void Main (string[] args) {
    Console.WriteLine("Ingrese el salario anterior del trabajador")
    float salario_anterior = float.Parse(Console.ReadLine());

    float incremento = salario_anterior * 0.25;
    float salario_actual = salario_anterior + incremento;
    Console.WriteLine($"El salario actual del trabajador es: {salario_actual}, el incremento fue de: {incremento}, en base al antiguo salario de {salario_anterior}");
    
  }
}
