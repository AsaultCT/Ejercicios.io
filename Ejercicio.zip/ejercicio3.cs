using System;
class MainClass {
  public static void Main (string[] args) {
    Console.WriteLine ("Ingresa el preusupuesto anual del hospital");
    float preusupuesto_anual = float.Parse(Console.ReadLine());
    float preusupuesto_ginecologia = preusupuesto_anual * 0.20;
    float preusupuesto_oncologia = preusupuesto_anual * 0.40;
    float preusupuesto_pediatra = preusupuesto_anual * 0.30;
    float preusupuesto_estetica = preusupuesto_anual * 0.10;

    Console.WriteLine($"Preusupuesto ginecología: {preusupuesto_ginecologia}");
    Console.WriteLine($"Presupuesto Oncología: {presupuesto_oncologia}");
    Console.WriteLine($"Presupuesto Pediatría: {presupuesto_pediatra}");
    Console.WriteLine($"Presupuesto Estética: {presupuesto_estetica}");
  }
}
