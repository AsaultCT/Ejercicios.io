using System;
class MainClass {
  public static void Main (string[] args) {
    Console.WriteLine ("Inversion total:");
    float inversion_total = float.Parse(Console.ReadLine());
    Console.WriteLine("Ingrese la cantidad de dinero que invirtio la primera persona");
    float primera_persona = float.Parse(Console.ReadLine());
    Console.Writeline("Ingrese la cantidad de dinero que invirtio la segunda persona");
    float segunda_persona = float.Parse(Console.ReadLine());
    Console.WriteLine("Ingrese la cantidad de dinero que invirtio la tercera persona");
    float tercera_persona = float.Parse(Console.Readline());

    float porcentaje_primera = primera_persona * 100 / inversion_total;
    float porcentaje_segunda = segunda_persona * 100 / inversion_total;
    float porcentaje_tercera = tercera_persona * 100 / inversion_total;

    Console.WriteLine($"Porcentaje de dinero invertido por la primera persona: {porcentaje_primera}%");
    Console.WriteLine($"Porcentaje de dinero invertido por la segunda persona: {porcentaje_segunda}%");
    Console.WriteLine($"Porcentaje de dinero invertido por la tercera persona: {porcentaje_tercera}%");
  }
}
